import React, { useState, useEffect } from 'react';

function EditorDashboard() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [editableData, setEditableData] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(process.env.REACT_APP_API_URL+{
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`,
          },
        });

        if (!response.ok) {
          throw new Error('Failed to fetch data');
        }

        const data = await response.json();
        setData(data); 
        setLoading(false); 
      } catch (error) {
        setError(error.message); 
        setLoading(false); 
      }
    };

    fetchData();
  }, []); 

  const handleEditClick = (item) => {
    setEditableData({ ...item }); 
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditableData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSaveClick = async () => {
    try {
      const response = await fetch(`/api/data/${editableData.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify(editableData),
      });

      if (!response.ok) {
        throw new Error('Failed to update data');
      }

      setData((prevData) =>
        prevData.map((item) =>
          item.id === editableData.id ? editableData : item
        )
      );
      setEditableData(null); 
    } catch (error) {
      setError(error.message); 
    }
  };

  return (
    <div className="editor-dashboard">
      <h2>Editor Dashboard</h2>

      {loading && <p>Loading data...</p>}

      {error && <p style={{ color: 'red' }}>Error: {error}</p>}

      {!loading && !error && (
        <>
          <h3>Editable Data List</h3>
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Timestamp</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {data.map((item) => (
                <tr key={item.id}>
                  <td>{item.id}</td>
                  <td>{item.name}</td>
                  <td>{new Date(item.timestamp).toLocaleString()}</td>
                  <td>
                    <button onClick={() => handleEditClick(item)}>Edit</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </>
      )}

      {editableData && (
        <div className="edit-form">
          <h3>Edit Item</h3>
          <form>
            <label>Name:</label>
            <input
              type="text"
              name="name"
              value={editableData.name}
              onChange={handleInputChange}
            />
            <label>Timestamp:</label>
            <input
              type="text"
              name="timestamp"
              value={editableData.timestamp}
              onChange={handleInputChange}
            />
            <button type="button" onClick={handleSaveClick}>
              Save Changes
            </button>
            <button type="button" onClick={() => setEditableData(null)}>
              Cancel
            </button>
          </form>
        </div>
      )}
    </div>
  );
}

export default EditorDashboard;
