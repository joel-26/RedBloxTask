const UserSchema = new
mongoose.Schema({

email: String,

password: String,

role: String, // Admin, Editor, Viewer
});
const User = mongoose.model('User',UserSchema);