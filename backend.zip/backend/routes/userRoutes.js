const express = require('express');
const User = require('../models/User'); 
const verifyToken = require('../middleware/authMiddleware');

const router = express.Router();

router.get('/', verifyToken(['Admin']), async (req, res) => {
    try {
        const users = await User.find();
        res.status(200).send(users);
    } catch (err) {
        console.error('Error fetching users:', err);
        res.status(500).send('Internal server error');
    }
});

module.exports = router;
